# WizBox
Wizard101 multiboxing tool. Open source. 

YouTube: https://youtube.com/c/Viscerator
Twitter: https://twitter.com/og_nizzler
